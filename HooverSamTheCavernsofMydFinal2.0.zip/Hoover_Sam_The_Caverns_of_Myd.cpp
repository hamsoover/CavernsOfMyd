/* The Caverns of Myd
   A text-based adventure game

   Author: Sam Hoover
   Date: 07/22/2019


*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <fstream>


using namespace std;

vector<string> rooms {"Entrance", "Waterfall Chamber", "Great Chasm", "Ruined Passage", "Casa Bonita", "Dead End", "Dark Chamber", "Treasure Room"};
vector<string> roomDescriptions;

string         StrToLower(string inputStr);
vector<string> SplitString(string inputStr);

/**************************Object Class*************************
****************************************************************/

class Object {

public:
    Object(string name, string description, bool takeable) {
        this->name        = name;
        this->description = description;
        this->takeable    = takeable;

        }
    Object() {
        this->name        = "ERROR";
        this->description = "ERROR";
        this->takeable    = false;
        }

    string GetName() const         {return name;}
    void   SetName(string name)    {this->name = name;}

    string GetDescription() const  {return description;}
    void   SetDescription(string description) {this->description = description;}
    void   PrintDescription();

    bool   IsTakeable() const      {return takeable;}

    bool operator==(Object& rsObject) {
        if (this->GetName() == rsObject.GetName())
            return true;
        return false;
    }


protected:
    string name;
    string description;
    bool   takeable;


};

/************************PrintDescription()*********************
    Prints Object's description, creating a linebreak at a
    space when greater than 100 characters.
***************************************************************/

void Object::PrintDescription() {
    string currentDescription = this->GetDescription();
    int lineLength = 0;

    cout << endl;
    for (int i = 0; i < currentDescription.length(); i++) {
        if (lineLength > 100 && currentDescription.at(i) == ' ') {
            cout << endl;
            lineLength = 0;
        }
        else {
            cout << currentDescription.at(i);
            lineLength++;
        }
    }
    cout << endl << endl;
}

/************************Exit Class*****************************
****************************************************************/

class Exit : public Object{

public:
    Exit(string name, string description, string destination) {
        this->name        = name;
        this->description = description;
        this->destination = destination;
        }
    Exit() {
        this->name        = name;
        this->description = description;
        this->destination  = destination;
        }

    string GetDestination() const {return destination;}
    void SetDestination(string destination) {this->destination = destination;}

private:
    string destination;

};

bool SearchInventory(vector<Object> userInventory, Object target);
bool SearchInventory(vector<Object> userInventory, string target);


/************************Room Class*****************************
****************************************************************/
class Room {

public:
    Room(string roomName, string roomDescription) {
        this->roomName        = roomName;
        this->roomDescription = roomDescription;
    }
    Room() {
        this->roomName        = "ROOM NAME ERROR";
        this->roomDescription = "ROOM DESCRIPTION ERROR";
    }

    string GetRoomName() const {return roomName;}
    void   SetRoomName(string roomName) {this-> roomName = roomName;}

    string GetRoomDescription() const {return roomDescription;}
    void   SetRoomDescription(string roomDescription) {this-> roomDescription = roomDescription;}

    void   AddExit(Exit exit);
    void   RemoveExit(Exit exit);
    vector<Exit> GetRoomExits() {return roomExits;}

    void   AddObject(Object object);
    void   RemoveObject(Object obj);
    void   RemoveObject(string objName);
    void   UpdateObjectDescription(Object object, string description);
    void   UpdateObjectDescription(string objName, string description);
    vector<Object> GetRoomObjects() {return roomObjects;}

    void   UpdateRoom(Object object);
    void   UpdateRoom(string objName);



private:
    string roomName;
    //vector<Item> roomItems;
    vector<Object> roomObjects;
    string roomDescription;
    vector<Exit> roomExits;
};

ostream& operator<<(ostream& os, Room& room) {
    os << room.GetRoomName();
    }


/***********************AddExit()*******************************
            Pushes exit to the Room's Exit vector
****************************************************************/
void Room::AddExit(Exit exit) {
    roomExits.push_back(exit);
}

/***********************RemoveExit()****************************
    Searches Room's Exit vector for exit and removes it.
***************************************************************/
void Room::RemoveExit(Exit exit) {
    for(vector<Exit>::iterator iter = roomExits.begin(); iter != roomExits.end(); iter++) {
        if (*iter == exit)
            roomExits.erase(iter);
    }
}

/**********************AddObject()******************************
        Pushes Object to Room's Object vector
****************************************************************/
void Room::AddObject(Object object) {
    roomObjects.push_back(object);
}

/***********************RemoveObject()****************************
    Searches Room's Object vector for Object and removes it
******************************************************************/
void Room::RemoveObject(Object obj) {

    for(int i = 0; i < roomObjects.size(); i++) {
        if (roomObjects.at(i) == obj)
            roomObjects.erase(roomObjects.begin() + i);
    }
}

void Room::RemoveObject(string objName) {

    for(int i = 0; i < roomObjects.size(); i++) {
        if (roomObjects.at(i).GetName() == objName)
            roomObjects.erase(roomObjects.begin() + i);
    }
}

/*******************UpdateObjectDescription()*********************
    Searches Room's Object vector of Object, and updates the
    objects description to the argument string
*****************************************************************/
void Room::UpdateObjectDescription(Object object, string description) {

    for (int i = 0; i < roomObjects.size(); i++) {
        if (roomObjects.at(i) == object)
            roomObjects.at(i).SetDescription(description);
    }
}


void Room::UpdateObjectDescription(string objName, string description) {

    for (int i = 0; i < roomObjects.size(); i++) {
        if (roomObjects.at(i).GetName() == objName)
            roomObjects.at(i).SetDescription(description);
    }
}

/**********************UpdateRoom()*******************************
    Helper function that updates the Room's variables when certain
    Objects are used or taken, based on the Object.
******************************************************************/
void Room::UpdateRoom(Object object) {

    if (object.GetName() == "LOGS") {
        this->UpdateObjectDescription("CAMP", "A small, abandoned TENT sits near the NORTH passage. There's "
                                      "a tattered SLEEPING BAG lying inside of the tent that looks to be in "
                                      "great condition, as if it could have been used just yesterday.");
    }
    else if (object.GetName() == "LIGHTER") {
        this->UpdateObjectDescription("SLEEPING BAG", "You could try taking this nice looking sleeping bag, but you want "
                       "as much room for treasure later as possible.");
    }
    else if (object.GetName() == "HOOK") {
        this->RemoveObject("SOMETHING");
        this->UpdateObjectDescription("POOL", "The POOL that you got the hook from. There's nothing there now.");
    }
    else if (object.GetName() == "ROPE") {
        this->UpdateObjectDescription("CAVE IN", "The walls of the cave have completely collapsed together here. You can't get through.");
    }

    this->RemoveObject(object.GetName());
}

void Room::UpdateRoom(string objName) {

    if (objName == "LOGS") {
    this->UpdateObjectDescription("CAMP", "A small, abandoned TENT sits near the NORTH passage. There's "
                                  "a tattered SLEEPING BAG lying inside of the tent that looks to be in "
                                  "great condition, as if it could have been used just yesterday.");
    }
    else if (objName == "LIGHTER") {
        this->UpdateObjectDescription("SLEEPING BAG", "You could try taking this nice looking sleeping bag, but you want "
                       "as much room for treasure later as possible.");
    }
    else if (objName == "HOOK") {
        this->RemoveObject("SOMETHING");
        this->UpdateObjectDescription("POOL", "The POOL that you got the hook from. There's nothing there now.");
    }
    else if (objName == "ROPE") {
        this->UpdateObjectDescription("CAVE IN", "The walls of the cave have completely collapsed together here. You can't get through.");
    }
    else if (objName == "BUTTON") {
        this->RemoveObject("BUTTON");
        this->RemoveObject("TILE");
        this->RemoveObject("WALL");
        this->RemoveObject("NORTH");
        Exit north("NORTH", "Well, there's an exit to the north now. Thanks to you. Go ahead and go, you've done enough damage.", "Dark Room");
        this->roomExits.push_back(north);
        this->roomDescription = "Well this used to be a dead end, before you went and blew up the other wall. You still owe me money for repairs. "
        "There are now exits to the NORTH and SOUTH. You monster.";
    }

    this->RemoveObject(objName);

}

Room FindRoom(string roomString, vector<Room> roomVector);

/************************Game Class*****************************
 ***************************************************************/
class Game {

public:
    Game(string userName, vector<Room> roomVector) {                     //Constructor for starting a new game (only userName inputted)
        this->userName    = userName;
        this->currentRoom = roomVector.at(0);
        this->roomVector  = roomVector;
        this->hookedChasm = false;
        this->raisedFlag  = false;
        this->blownWall   = false;
    }
    Game(string userName, Room currentRoom, vector<Object> userInventory, vector<Room> roomVector, bool hookedChasm, bool raisedFlag, bool blownWall) {
        this->userName      = userName;               //Constructor for resuming saved game (userName, current room, and inventory all inputted)
        this->currentRoom   = currentRoom;
        this->userInventory = userInventory;
        this->roomVector    = roomVector;
        this->hookedChasm   = hookedChasm;
        this->raisedFlag    = raisedFlag;
        this->blownWall     = blownWall;
    }
    Game() {                                    //Default constructor, not planned to be used.
        userName    = "NONAME";
    }

    void           Play();
    void           PrintRoomDescription();
    vector<string> SplitPlayerInput     (string playerInput);
    void           ProcessPlayerCommand (vector<string> splitInput);
    void           SaveGame();

    void           PrintHelp (vector<string> splitInput);
    void           Look      (vector<string> splitInput);
    void           Go        (vector<string> splitInput);
    void           Take      (vector<string> splitInput);
    void           Use       (vector<string> splitInput);
    void           Toss      (vector<string> splitInput);
    void           Raise     (vector<string> splitInput);
    void           Push      (vector<string> splitInput);
    void           PrintInventory();

    string         GetUserName() const              {return userName;}
    void           SetUserName(string userName)     {this->userName = userName;}

    Room           GetCurrentRoom() const           {return currentRoom;}
    void           SetCurrentRoom(Room currentRoom) {this->currentRoom = currentRoom;}

    void           AddToInventory(Object objToAdd);
    void           RemoveFromInventory(string objName);
    int            ObjectInInventory(string objName);

    bool           GetHookedChasm() const           {return hookedChasm;}
    void           SetHookedChasm(bool hookedChasm) {this->hookedChasm = hookedChasm;}

    bool           GetRaisedFlag()  const           {return raisedFlag;}
    void           SetRaisedFlag(bool raisedFlag)   {this->raisedFlag = raisedFlag;}

    bool           GetBlownWall()   const           {return blownWall;}
    void           SetBlownWall(bool blownWall)     {this->blownWall  = blownWall;}

    void           ReplaceRoomInVector();





private:
    vector<Object> userInventory;
    string       userName;
    Room         currentRoom;
    vector<Room> roomVector;
    bool         hookedChasm;
    bool         raisedFlag;
    bool         blownWall;
};
/******************Play()**************************************
    Primary game-handling class. Contains loop that gets
    input from the player and hands it off to other functions
    for processing
**************************************************************/
void Game::Play() {
    string         userInput;
    vector<string> splitInput;

    cout << currentRoom.GetRoomName() << endl;
    PrintRoomDescription();

    while (StrToLower(userInput) != "quit") {



        cout << "What would you like to do? (Enter your command. Type \"HELP\" for a list of commands. Type \"QUIT\" to quit.):" << endl;
        getline(cin, userInput);

        cout << endl;
        for (int i = 0; i < 110; i++)
            cout << "-";
        cout << endl;

        splitInput = SplitString(userInput);

        if(splitInput.size() > 0) {
            ProcessPlayerCommand(splitInput);
        }

        if (currentRoom.GetRoomName() == "Treasure Room") {
            cout << "CONGRATULATIONS!" << endl;
            //cout << "Would you like to start a new game?" << endl; FIXME: Create option to start game over again.
            return;
        }

    }

    SaveGame();
}

/*****************PrintRoomDescription()************************
    Prints the description of the room, creating a linebreak
    at the next space character when over 100 characters
***************************************************************/
void Game::PrintRoomDescription() {
    string currentDescription = currentRoom.GetRoomDescription();
    int lineLength = 0;

    cout << endl;
    for (int i = 0; i < currentDescription.length(); i++) {
        if (lineLength > 100 && currentDescription.at(i) == ' ') {
            cout << endl;
            lineLength = 0;
        }
        else {
            cout << currentDescription.at(i);
            lineLength++;
        }
    }
    cout << endl << endl;
}

/*************************SplitPlayerInput()*****************/


/**********************ProcessPlayerCommand()********************
    Intermediary function that determines which function to
    call based on the first word of the player input (the "command")
****************************************************************/
void Game::ProcessPlayerCommand(vector<string> splitInput) {
    const string commandList[] = {"help", "look", "go", "take", "use", "toss", "inventory", "save"};

    string command = splitInput.at(0);

    if (command == "help")
        PrintHelp(splitInput);
    else if (command == "look" || command == "examine")
        Look(splitInput);
    else if (command == "go")
        Go(splitInput);
    else if (command == "take" || command == "get" || command == "grab")
        Take(splitInput);
    else if (command == "use")
        Use(splitInput);
    else if (command == "toss" || command == "throw")
        Toss(splitInput);
    else if (command == "inventory")
        PrintInventory();
    else if (command == "save")
        SaveGame();
    else if (command == "raise" && currentRoom.GetRoomName() == "Casa Bonita")
        Raise(splitInput);
    else if (command == "push" && currentRoom.GetRoomName() == "Dead End")
        Push(splitInput);
    else if (command == "quit");
    else
        cout << endl <<  "I don't understand \"" << splitInput.at(0) << "\". Please try again." << endl << endl;


}

/**********************SaveGame()*******************************
    Writes game information (Name, Current Room, inventory,
    and a few boolean variables) to a .txt file that can be
    loaded to resume gameplay
****************************************************************/
void Game::SaveGame() {
    ofstream saveOutput;

    saveOutput.open("savefile.txt");

    saveOutput << userName << endl;
    saveOutput << currentRoom.GetRoomName() << endl;
    saveOutput << (hookedChasm ? "true" : "false") << endl;
    saveOutput << (raisedFlag  ? "true" : "false") << endl;
    saveOutput << (blownWall   ? "true" : "false");
    if (!userInventory.empty()){
        for (Object obj : userInventory) {
            saveOutput << endl;
            saveOutput << obj.GetName() << endl;
            saveOutput << obj.GetDescription();
        }
    }
    saveOutput.close();
}

/************************PrintHelp()*****************************
    Prints a (not exhaustive) list of commands (when used alone)
    or a description of a command (when paired with that command)
****************************************************************/
void Game::PrintHelp(vector<string> splitInput) {
    map<string, string> commandHelp;
    commandHelp["look"]      = "Use \"LOOK\" alone to examine the room. Use \"LOOK\" followed by an object to look at it more closely.";
    commandHelp["go"]        = "Use \"GO\" with a room exit name to proceed to another room.";
    commandHelp["take"]      = "Use \"TAKE\" followed by an object to take it (if it can be taken)";
    commandHelp["use"]       = "Use \"USE\" followed by an item in your inventory to attempt to use it.\nSome items need to be followed by what to use it on. Example: \"Use key on door\"";
    commandHelp["toss"]      = "Use \"TOSS\" to throw certain items. To toss something in a specific location, try \"Toss <item> in <location>\"";
    commandHelp["inventory"] = "Use \"INVENTORY\" to view your current inventory.";
    commandHelp["save"]      = "Use \"SAVE\" to save your current game.";

    if (splitInput.size() == 1) {
        cout << endl << "Here is a list of some commands you can use:" << endl;
        cout << "\"HELP\", \"LOOK\", \"GO\", \"TAKE\", \"USE\", \"TOSS\", \"INVENTORY\", \"SAVE\"" << endl;
        cout << "You can use \"HELP\" <command> for a more detailed description of each command." << endl << endl;
    }

    else {
        cout << commandHelp[splitInput.at(1)] << endl << endl;
    }
}

/*************************Look()*********************************
    Allows player to get a description of the general surroundings
    or a specific object.
****************************************************************/
void Game::Look(vector<string> splitInput) {

    vector<Object> roomObjects;
    vector<Exit>   roomExits;
    string location;
    bool objectFound = false;

    if (splitInput.size() == 1)
        PrintRoomDescription();
    else {
        int i = (splitInput.at(1) == "at" && splitInput.size() > 2 ? 2 : 1);
        location = splitInput.at(i);

        for (i = i+1; i < splitInput.size(); i++)
            location = location + " " + splitInput.at(i);

        roomObjects = currentRoom.GetRoomObjects();
        for (Object object : roomObjects) {
            if (StrToLower(object.GetName()) == location) {
                object.PrintDescription();
                objectFound = true;
            }
        }

        roomExits = currentRoom.GetRoomExits();
        for (Exit exit : roomExits) {
            if (StrToLower(exit.GetName()) == location) {
                exit.PrintDescription();
                objectFound = true;
            }
        }

        for (Object obj : userInventory) {
            if (StrToLower(obj.GetName()) == location) {
                obj.PrintDescription();
                objectFound = true;
            }
        }

        if (!objectFound)
            cout << endl << "Look at " << location << "??? No thanks!" << endl << endl;
    }
}

/**************************Go()**********************************
    Travels from one Room to another Room via an Exit
****************************************************************/
void Game::Go(vector<string> splitInput) {

    bool validExit = false;
    string location;
    vector<Exit> roomExits;

    if (splitInput.size() == 1) {
        cout << endl << "Go? Just go? I don't know where you want to go!" << endl << endl;
    }
    else {
        location = splitInput.at(1);
        for (int i = 2; i < splitInput.size(); i++)
            location = location + " " + splitInput.at(i);
        roomExits = currentRoom.GetRoomExits();
        for (Exit exit : roomExits) {
            if (StrToLower(exit.GetName()) == location) {

                currentRoom = FindRoom(exit.GetDestination(), roomVector);

                PrintRoomDescription();

                validExit = true;
            }

        }
        if (!validExit)
            cout << endl << "Go " << location << "??? Trust me, you don't want to go there." << endl << endl;
    }
}

/***************************Take()*******************************
    If an object is able to be picked up, places the item in
    the player's inventory and removes it from the Room
****************************************************************/
void Game::Take(vector<string> splitInput) {
    vector<Object> roomObjects = currentRoom.GetRoomObjects();
    string target;
    bool tookObj = false;

    if (splitInput.size() == 1) {
        cout << endl << "Take take take. Why do you always take, but never give? (Please tell me what to take)." << endl << endl;
    }

    else {
        target = splitInput.at(1);
        for (int i = 2; i < splitInput.size(); i++) {
            target = target + " " + splitInput.at(i);
        }
        if (SearchInventory(userInventory, target))
            cout << endl << "You already have that." << endl << endl;
        else {
            if (target == "enchiladas")
                target = "enchilada dinner";
            for (Object obj : roomObjects) {
                if (StrToLower(obj.GetName()) == target && obj.IsTakeable()) {
                        currentRoom.UpdateRoom(obj);
                        userInventory.push_back(obj);

                        tookObj = true;
                        cout << endl << "You took the " << target << "." << endl << endl;
                }
            }
            if (!tookObj) {
                cout << endl << "Nope. I wouldn't touch " << target << " with a thirty-nine-and-a-half-foot pole." << endl << endl;
            }
        }
    }
    ReplaceRoomInVector();
}

/***************************Use()********************************
    Allows an item to be used on an Object in the room or another
    item in the inventory to combine them
****************************************************************/
void Game::Use(vector<string> splitInput) {

    string usedItem;
    string target = "";
    bool   targetText = false;      //Used to detect when the vector switches from the item used to the target (by looking for the word "on".

    cout << endl;

    if (splitInput.size() == 1) {
        cout << "Use gots to be kidding me! (You need to specify what you want to use.)" << endl << endl;
    }

    else {

        usedItem = splitInput.at(1);
        for (int i = 2; i < splitInput.size(); i++) {
            if (splitInput.at(i) == "on" || splitInput.at(i) == "with") {
                targetText = true;
            }
            else if (targetText){
                if (target == "") {
                    target += splitInput.at(i);
                }
                else {
                    target = target + " " + splitInput.at(i);
                }
            }
            else {
                usedItem = usedItem + " " + splitInput.at(i);
            }

        }
        if (usedItem == "enchiladas") {
            usedItem = "enchilada dinner";
        }

        if (usedItem == "flag" && currentRoom.GetRoomName() == "Casa Bonita") {
            cout << "You might be able to use the flag, but how? Maybe something I type in here will \"raise\" some "
            "awareness for you. Get it? Raise? Raise the flag." << endl << endl;
        }
        else if (!SearchInventory(userInventory, usedItem))
            cout << "Use " << usedItem << "? You don't even HAVE " << usedItem << endl << endl;
        else {
            if (usedItem == "lighter") {
                if (target == "") {
                    cout << "You flick the lighter on and off a few times. It works, but barely gives off any light on its own." << endl << endl;
                }
                else if (target == "logs" && SearchInventory(userInventory, "logs")) {
                    cout << "You hold the lighter to the logs, but to no avail. They're too damp to catch fire." << endl << endl;
                }
                else if (target == "dry logs" && SearchInventory(userInventory, "dry logs")) {
                    if (currentRoom.GetRoomName() == "Dark Room") {
                        cout << "You flick on the lighter and hold it to the DRY LOGS. Flame takes to them as they start to burn!" << endl;
                        cout << "You got FIRE! I don't know how, but you've put the fire in your inventory. Now you can see in the dark!" << endl << endl;
                        RemoveFromInventory("DRY LOGS");
                        Object fire("FIRE", "A hot, bright fire flickers on the logs. I'm still not sure how you're just holding these.", true);
                        userInventory.push_back(fire);
                        currentRoom.SetRoomDescription("The bright light from your fire fills the room, revealing that there is a second exit to the WEST in this room. "
                    "The room is otherwise completely empty. The exit to the SOUTH returns to the hallway (that you blew up, by the way).");
                        Exit west("WEST", "The exit to the west can now be seen due to the fire in your inventory. Who knows where it leads?", "Treasure Room");
                        currentRoom.AddExit(west);
                    }
                    else {
                        cout << "You probably should do that in a place that needs light." << endl << endl;
                    }
                }
                else {
                    cout << "Slow down there pyromaniac. You can't use the lighter on that!" << endl << endl;
                }
            }  //endif lighter

            else if (usedItem == "logs") {
                if (target == "") {
                    cout << "I'm not sure what you plan on doing with some wet logs..." << endl << endl;
                }
                else if ((target == "waterfall" || target == "pool" || target == "water") && currentRoom.GetRoomName() == "Waterfall Chamber") {
                    cout << "You make the already-wet logs even wetter. How productive." << endl << endl;
                }
                else if (target == "enchilada dinner" || target == "enchiladas" && SearchInventory(userInventory, "enchilada dinner")) {
                    cout << "For some weird reason, you use the enchiladas to dry off the logs. And for some weirder reason, it worked." << endl;
                    cout << "You got the DRY LOGS!" << endl << endl;
                    RemoveFromInventory("ENCHILADA DINNER");
                    RemoveFromInventory("LOGS");
                    Object drylogs("DRY LOGS", "The now-dry logs could probably be ignited by a flame of some sort. It would be a good way of "
                                   "lighting up a room.", true);
                    userInventory.push_back(drylogs);
                }
                else {
                    cout << "You whack " << target << " with the logs. Nothing happens." << endl << endl;
                }
            } //endif logs

            else if (usedItem == "enchilada dinner") {
                if (target == "") {
                    cout << "You take a few bites of the enchiladas. Yum." << endl << endl;
                }
                else if (target == "logs") {
                    cout << "For some weird reason, you use the enchiladas to dry off the logs. And for some weirder reason, it worked." << endl;
                    cout << "You got the DRY LOGS!" << endl << endl;
                    RemoveFromInventory("ENCHILADA DINNER");
                    RemoveFromInventory("LOGS");
                    Object drylogs("DRY LOGS", "The now-dry logs could probably be ignited by a flame of some sort. It would be a good way of "
                                   "lighting up a room.", true);
                    userInventory.push_back(drylogs);
                }
                else {
                    cout << "You cover the " << target << " with sauce from the enchiladas. Congratulations, you made the " << target << "smell delicious!" << endl << endl;
                }
            } // endif enchilada dinner

            else if (usedItem == "hook") {
                if (target == "") {
                    cout << "You do your best pirate impersonation. Arrr." << endl << endl;
                }
                else if (target == "rope" && SearchInventory(userInventory, "rope")) {
                    cout << "You tie the rope to the hook, creating a GRAPPLING HOOK!" << endl << endl;
                    RemoveFromInventory("HOOK");
                    RemoveFromInventory("ROPE");
                    Object grapplinghook("GRAPPLING HOOK", "A sturdy grappling hook, could be used to cross a chasm for example.", true);
                    userInventory.push_back(grapplinghook);
                }
                else if (target == "chasm" && currentRoom.GetRoomName() == "Great Chasm") {
                    cout << "The hook won't work by itself. You need a rope. Plus, you'll want to TOSS the hook." << endl << endl;
                }
                else {
                    cout << "Probably shouldn't use the HOOK on that... you might scratch it." << endl << endl;
                }
            } //endif hook

            else if(usedItem == "rope") {
                if (target == "") {
                    cout << "You swing the rope around in your best cowboy impersonation. Yeehaw." << endl << endl;
                }
                else if (target == "hook" && SearchInventory(userInventory, "hook")) {
                    cout << "You tie the rope to the hook, creating a GRAPPLING HOOK!" << endl << endl;
                    RemoveFromInventory("HOOK");
                    RemoveFromInventory("ROPE");
                    Object grapplinghook("GRAPPLING HOOK", "A sturdy grappling hook, could be used to cross a chasm for example.", true);
                    userInventory.push_back(grapplinghook);
                }
            }//endif rope

            else if (usedItem == "grappling hook") {
                if (!(currentRoom.GetRoomName() == "Great Chasm")) {
                    cout << "This seems like a terrible place to use the grappling hook. Way too cramped. Try somewhere else." << endl << endl;
                }
                else {
                    cout << "How do you want to use it? Maybe you should \"toss\" another idea out there." << endl << endl;
                }
            }//endif grappling hook

            else if (usedItem == "dry logs") {
                if (target == "lighter" && SearchInventory(userInventory, "lighter")) {
                    if (currentRoom.GetRoomName() == "Dark Room") {
                        cout << "You flick on the lighter and hold it to the DRY LOGS. Flame takes to them as they start to burn!" << endl;
                        cout << "You got FIRE! I don't know how, but you've put the fire in your inventory. Now you can see in the dark!" << endl << endl;
                        RemoveFromInventory("DRY LOGS");
                        Object fire("FIRE", "A hot, bright fire flickers on the logs. I'm still not sure how you're just holding these.", true);
                        userInventory.push_back(fire);
                        currentRoom.SetRoomDescription("The bright light from your fire fills the room, revealing that there is a second exit to the WEST in this room. "
                    "The room is otherwise completely empty. The exit to the SOUTH returns to the hallway (that you blew up, by the way).");
                        Exit west("WEST", "The exit to the west can now be seen due to the fire in your inventory. Who knows where it leads?", "Treasure Room");
                        currentRoom.AddExit(west);
                    }
                    else {
                        cout << "You probably should do that in a place that needs light." << endl << endl;
                    }
                }
                else if ((target == "waterfall" || target == "pool" || target == "water") && currentRoom.GetRoomName() == "Waterfall Chamber") {
                    cout << "You just made the logs dry. I don't think it's a good idea to make them wet again." << endl << endl;
                }
                else {
                    cout << "I'm not really sure what " << target << " would do to the logs, and you might need them. Let's not." << endl << endl;
                }
            } //endif "dry logs"




            else {
                cout << "USE ITEM INVENTORY ERROR" << endl;
            }
        }
    }
    ReplaceRoomInVector();

}

/***************************Toss()*******************************
    In this version of the game, only used in the Great Chasm
    Room to throw the Grappling Hook Object to allow access to
    its eastern exit
*****************************************************************/
void Game::Toss(vector<string> splitInput) {

    string thrownItem;
    cout << endl;

    if (splitInput.size() == 1) {
        cout << "Toss what? I need to know what to toss." << endl << endl;
    }

    else {
        thrownItem = splitInput.at(1);
        for (int i = 2; i < splitInput.size(); i++) {
            thrownItem = thrownItem + " " + splitInput.at(i);
        }

        if (SearchInventory(userInventory, thrownItem)) {
            if (thrownItem == "grappling hook") {
                if (currentRoom.GetRoomName() == "Great Chasm") {
                    Exit east("EAST", "temp", "Casa Bonita");
                    currentRoom.AddExit(east);
                    currentRoom.RemoveObject("EAST");
                    cout << "With a great heave, you throw the grappling hook across the chasm. It lands with a thud, and as you pull it" << endl;
                    cout << "taut it catches on a solid boulder on the other side. Great! Now you can get to the EAST exit." << endl << endl;
                    currentRoom.UpdateObjectDescription("CHASM", "Now that you've hooked your way across the CHASM, you can get to the EAST exit! "
                                                        "Just don't look down.");
                    currentRoom.SetRoomDescription("In the center of this room is a large CHASM splitting the room in two. You can't see the bottom. "
                    "You can see an exit to the EAST that you can now reach thanks to your grappling hook. The exit to the SOUTH "
                    "returns you to the entrance of the cavern.");
                    hookedChasm = true;
                    RemoveFromInventory("GRAPPLING HOOK");
                }
            }
            else {
                cout << "You might think you could throw " << thrownItem << ", but you can't. Blame the developer." << endl << endl;
            }
        }

        else {
            cout << "You can't throw " << thrownItem << ". You don't even HAVE " << thrownItem << "." << endl << endl;
        }
    }
    ReplaceRoomInVector();
}

/*************************PrintInventory()***********************
    Prints out each item in the user's inventory separated by
    spaces
****************************************************************/
void Game::PrintInventory() {
    cout << "Current Inventory:";
    for (Object obj : userInventory) {
        cout << " " << obj.GetName();
    }
    cout << "." << endl << endl;
}

/**************************Raise()******************************
    In this version of the game, only used in Casa Bonita
    to raise the flag to receive the Enchilada Dinner
***************************************************************/
void Game::Raise(vector<string> splitInput) {

    string raisedItem = "";
    cout << endl;

    if (raisedFlag) {
        cout << "Oompa Loompa doom-pa-dee-do\n"
        "I've got a perfect puzzle for you\n"
        "Oompa Loompa doom-pa-dee-dee\n"
        "If you are wise you'll listen to me\n"
        "What do you get scarfing down tacos?\n"
        "Eating and eating till you nearly explode\n"
        "What are you at getting terribly fat?\n"
        "What do you think will come...from...that?\n"
        "(You already raised the flag)" << endl << endl;
    }
    else {
        if (splitInput.size() == 1) {
            cout << "You're almost there! But not just \"raise\". Raise what?" << endl << endl;
        }

        else {
            int i = (splitInput.at(1) == "the" && splitInput.size() > 2 ? 2 : 1);
            raisedItem = splitInput.at(i);

            if (StrToLower(raisedItem) == "flag") {
                    cout << "A waiter instantly sees your raised flag and rushes to your table, leaving an ENCHILADA DINNER behind." << endl;
                    cout << "The plate is incredibly hot, as the waiter made sure to tell you before he went to serve another table." << endl << endl;
                    //currentRoom.updateRoom("flag");
                    this->raisedFlag = true; //FIXE ME: FINISH PROCESSING RAISING FLAG
                    Object enchiladaDinner("ENCHILADA DINNER", "A piping hot plate of enchiladas, rice, and beans. The heat coming off of the platter "
                           "is so intense, it could probably dry off something very wet. Try not to burn yourself.", true);
                    currentRoom.UpdateObjectDescription("FLAG", "The flag you raised to get a delicious Mexican dish. You've already raised it, "
                                                        "so it has no use to you now.");
                    currentRoom.AddObject(enchiladaDinner);
                    currentRoom.SetRoomDescription("The warm smell of Tex-Mex fills the air. Speakers, somewhere, are blasting mariachi music "
                    "and several diners are enjoying their meals. The host welcomes you and brings you to a table. On the table "
                    "is your ENCHILADA DINNER you had brought to you earlier. Exits are to the NORTH and WEST (returning you to the Chasm).");
            }
            else {
                cout << "Seriously? Just type \"raise flag\". Or \"raise the flag\". Both work." << endl << endl;
            }
        }
    }
    ReplaceRoomInVector();
}

/*************************Push()********************************
    In this version of the game, only used in the Dead End
    to blow up the northern wall to create an Exit to the
    Dark Chamber
***************************************************************/
void Game::Push(vector<string> splitInput) {

    string usedItem;

    if (splitInput.size() == 1) {
        cout << "It seems like you accidentally typed \"push\". I assure you, there is nothing worth pushing in this room. Don't try it." << endl << endl;
    }

    else {
        usedItem = splitInput.at(1);

            if (usedItem == "button" && !blownWall) {
                cout << "Wait wait I said not to-KABOOM" << endl;
                cout << "Well, you blew it. Literally. The entire wall has exploded open, throwing debris everywhere." << endl;
                cout << "I hope you're happy with yourself." << endl << endl;
                currentRoom.UpdateRoom("BUTTON");
                blownWall = true;
            }
            else if (usedItem == "button") {
                cout << "You already did that. Haven't you caused enough destruction for one day?" << endl << endl;
            }
            else {
                cout << "I'm not sure what you mean by \"push " << usedItem << ", but it sounds like a bad idea. Don't push anything in here." << endl << endl;
            }
    }

    ReplaceRoomInVector();
}
/********************AddToInventory()***************************
    Ensures that object is not already in inventory, and if not,
    pushes it to the inventory vector. Currently obsolete
***************************************************************/
void Game::AddToInventory(Object objToAdd) {

/*    if (ObjectInInventory(objToAdd) >= 0) {
            cout << "Item duplicate error." << endl;
    }
    else {
        userInventory.push_back(objToAdd);
    }*/
}

/********************RemoveFromInventory()***********************
    Searches inventory for an object with the argument string
    as its name and removes it
****************************************************************/

void Game::RemoveFromInventory(string objName) {

    if (ObjectInInventory(objName) >= 0) {
        userInventory.erase(userInventory.begin() + ObjectInInventory(objName));
    }
    else {
        cout << "Item not in inventory error" << endl;
    }
}
/********************ObjectInInventory()***************************
    Searches inventory vector and returns the index of the
    Object if present, otherwise returns -1
******************************************************************/
int Game::ObjectInInventory(string objName) {
    for (int i = 0; i < userInventory.size(); i++)
    {
        if (userInventory.at(i).GetName() == objName) {
            return i;
        }
    }
    return -1;
}

/*******************ReplaceRoomInVector()**************************
    Function attempting to fix bug where the Room isn't being
    permanently updated upon taking an item (when leaving and
    returning to a room). The function is currently working but
    does not fix the bug
******************************************************************/
void Game::ReplaceRoomInVector() {
    for (int i = 0; i < roomVector.size(); i++) {
        if (currentRoom.GetRoomName() == roomVector.at(i).GetRoomName()) {
            roomVector.at(i) = currentRoom;
        }
    }
}

//bool         SearchInventory(vector<Object> userInventory, Object target);
void         SetEntrance(vector<Room>& roomVector, vector<Object> userInventory);
void         SetWaterfallChamber(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm);
void         SetGreatChasm(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm);
void         SetRuinedPassage(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm);
void         SetCasaBonita(vector<Room>& roomVector, vector<Object> userInventory, bool raisedFlag);
void         SetDeadEnd(vector<Room>& roomVector, vector<Object> userInventory, bool blownWall);
void         SetDarkRoom(vector<Room>& roomVector, vector<Object> userInventory);
void         SetTreasureRoom(vector<Room>& roomVector, vector<Object> userInventory);
void         SetRooms(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm, bool raisedFlag, bool blownWall);
void         PrintTitle();



Object CreateItem(vector<string> inventoryStringVector);


/******************************main()*****************************************
    New game creation and Loading game are handled within main
*****************************************************************************/
int main(void)
{
    string userName     = "NONAME";
    Room   currentRoom;
    string roomString   = "";
    string saveResponse = "";
    string hookedLine   = "";
    string raisedLine   = "";
    string blownLine    = "";

    string inventoryLine = "";
    vector<string> inventoryStringVector;
    vector<Object> userInventory;

    vector<Room> roomVector;

    ifstream saveFile;

    PrintTitle();

    while (saveResponse != "new" && saveResponse != "load") {
        cout << "Would you like to start a new game, or load a previous game? (Type \"new\" or \"load\"): ";

        getline(cin, saveResponse);

        if(saveResponse != "new" && saveResponse != "load") {
            cout << "Invalid response. Please input \"new\" or \"load\"." << endl << endl;
        }
    }
    if (saveResponse == "load") {

        cout << "Checking for previous save data..." << endl;

        saveFile.open("savefile.txt");

        if (saveFile.is_open())  {
            getline(saveFile, userName);
            getline(saveFile, roomString);
            getline(saveFile, hookedLine);
            getline(saveFile, raisedLine);
            getline(saveFile, blownLine);

            while (!saveFile.eof()) {
                getline(saveFile, inventoryLine);
                inventoryStringVector.push_back(inventoryLine);
                getline(saveFile, inventoryLine);
                inventoryStringVector.push_back(inventoryLine);

                if (!inventoryStringVector.empty())
                    userInventory.push_back(CreateItem(inventoryStringVector));
                inventoryStringVector.clear();
            }
            saveFile.close();

            SetRooms(roomVector, userInventory, (hookedLine == "true" ? true : false), (raisedLine == "true" ? true : false), (blownLine == "true" ? true : false));

            currentRoom = FindRoom(roomString, roomVector);

            cout << "Welcome back " << userName << "!" << endl;
            Game newGame(userName, currentRoom, userInventory, roomVector, (hookedLine == "true" ? true : false), (raisedLine == "true" ? true : false), (blownLine == "true" ? true : false));
            newGame.Play();
        }

        else {
                cout << "No save game detected. New game will be created." << endl;
                cout << "What is your name? ";
                getline(cin, userName);
                cout << endl;

                cout << userName << "? That's the strangest name I've ever heard!" << endl;
                cout << "No matter. Welcome to the Caverns of Myd!" << endl;

                cout << endl << "After traveling many nights, you have finally encountered the legendary \"Caverns of Myd\", a system" << endl;
                cout << "of caves rumored to contain great treasure. Many have entered the caverns, but none have ever left. You hope to be the" << endl;
                cout << "first adventurer to explore the caverns, claim the treasure, and return alive. Do you have what it takes?" << endl;
                cout << "Then step forward, and enter the caverns..." << endl << endl;

                SetRooms(roomVector, userInventory, false, false, false);

                currentRoom = roomVector.at(0);

                Game newGame(userName, roomVector);
                newGame.Play();
        }
    }

    else {
        cout << "What is your name? ";
        getline(cin, userName);
        cout << endl;

        cout << userName << "? That's the strangest name I've ever heard!" << endl;
        cout << "No matter. Weclome to the Caverns of Myd!" << endl;

        cout << endl << "After traveling many nights, you have finally encountered the legendary \"Caverns of Myd\", a system" << endl;
        cout << "of caves rumored to contain great treasure. Many have entered the caverns, but none have ever left. You hope to be the" << endl;
        cout << "first adventurer to explore the caverns, claim the treasure, and return alive. Do you have what it takes?" << endl;
        cout << "Then step forward, and enter the caverns..." << endl << endl;

        SetRooms(roomVector, userInventory, false, false, false);

        currentRoom = roomVector.at(0);

        Game newGame(userName, roomVector);
        newGame.Play();
    }


    return 0;
}

/*********************************SetRooms()**************************
    Intermediary function that calls the Room initializer functions
*********************************************************************/
void SetRooms(vector<Room> &roomVector, vector<Object> userInventory, bool hookedChasm, bool raisedFlag, bool blownWall) {

    SetEntrance(roomVector, userInventory);
    SetWaterfallChamber(roomVector, userInventory, hookedChasm);
    SetGreatChasm(roomVector, userInventory, hookedChasm);
    SetRuinedPassage(roomVector, userInventory, hookedChasm);
    SetCasaBonita(roomVector, userInventory, raisedFlag);
    SetDeadEnd(roomVector, userInventory, blownWall);
    SetDarkRoom(roomVector, userInventory);
    SetTreasureRoom(roomVector, userInventory);
}
/**********************************SetEntrance()*********************************
    Initializes the Entrance Room based on any objects in the player's
    inventory (when the game has been loaded)
********************************************************************************/
void SetEntrance(vector<Room>& roomVector, vector<Object>userInventory) {
    Room entrance("Entrance", "You are in a cold, dank cavern. Light pours in from the MOUTH of the cave to the south. "
                   "There are a few BOULDERS near the entrance. There are passages to the WEST, NORTH, and EAST. "
                   "You hear water flowing from the WEST passage. Near the NORTH passage is a small abandoned CAMP.");


    Object boulders("BOULDERS", "Several large boulders are arranged in a pattern here. I think it's a smiley face.", false);
    Object camp("CAMP", "A small, abandoned TENT sits near the NORTH passage. There are LOGS arranged in a campfire "
                "in front, too cold and wet now to light. There's a tattered SLEEPING BAG lying inside of the tent "
                "that looks to be in great condition, as if it could have been used just yesterday.", false);
    Object mouth("MOUTH", "The mouth of the cave provides a lot of light. It's a good thing too, because "
                 "you're scared of the dark.", false);
    Object tent("TENT", "The tent has seen some better days. It's a good thing that you don't need shelter, "
                "as it would barely cover you!", false);
    Object logs("LOGS", "These logs look very wet, certainly not good for lighting.", true);
    Object sleepingBag("SLEEPING BAG", "You could try taking this nice looking sleeping bag, but you want "
                       "as much room for treasure later as possible. There is a small LIGHTER laying on top.", false);
    Object lighter("LIGHTER", "This lighter still feels like it has plenty of fluid in it.", true);

    entrance.AddObject(boulders);
    entrance.AddObject(camp);
    entrance.AddObject(mouth);
    entrance.AddObject(tent);
    entrance.AddObject(logs);
    entrance.AddObject(lighter);
    entrance.AddObject(sleepingBag);
    if (SearchInventory(userInventory, logs))
        entrance.UpdateRoom(logs);
    if (SearchInventory(userInventory, lighter))
        entrance.UpdateRoom(lighter);

    Exit west("WEST", "There's probably some sort of Waterfall Chamber down this way. Might be good to check out, "
              "just don't go chasing it.", "Waterfall Chamber");
    Exit north("NORTH", "The northern passageway looks to be the biggest, but it winds enough that you can't see "
               "what is on the other side.", "Great Chasm");
    Exit east("EAST", "The eastern passage is covered with many rocks and debris. It might be a bit dangerous.",
              "Ruined Passage");

    entrance.AddExit(west);
    entrance.AddExit(north);
    entrance.AddExit(east);

    roomVector.push_back(entrance);

}

/***************************SetWaterfallChamber()*****************************
    Initializes the Waterfall Chamber based on Objects in the user's
    inventory and if the grappling hook has been thrown
******************************************************************************/
void SetWaterfallChamber(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm) {
    Room waterfallChamber("Waterfall Chamber", "A large WATERFALL cascades down the side of the northern cave wall. At "
                        "its base is a POOL of WATER. It doesn't look like there's much else here other than the EAST "
                        "exit that leads back to the entrance.");

    Object waterfall("WATERFALL", "You're not really sure where the source of this waterfall is, but it's sure "
                     "to be the source of all the humidity in the caverns.", false);
    Object pool("POOL", "The pool is pretty murky, but there looks to be SOMETHING underneath the water on the "
                "floor of the pool", false);
    Object water("WATER", "The water here looks murky. You probably shouldn't drink it.", false);
    Object something("SOMETHING", "As you look closer at the SOMETHING, you realize it's a metal climber's HOOK. "
                     "Not sure where the rope is (or the climber).", false);
    Object hook("HOOK", "A metal climber's hook. If you had some rope it might be a great way to get across a "
                "large gap of some sort.", true);

    waterfallChamber.AddObject(waterfall);
    waterfallChamber.AddObject(pool);
    waterfallChamber.AddObject(water);
    waterfallChamber.AddObject(something);
    waterfallChamber.AddObject(hook);
    if (SearchInventory(userInventory, hook) || SearchInventory(userInventory, "GRAPPLING HOOK") || (hookedChasm == true)) {
        waterfallChamber.UpdateRoom(hook);
    }

    Exit east("EAST", "The eastern exit leads you back into the entrance of the caverns.", "Entrance");

    waterfallChamber.AddExit(east);

    roomVector.push_back(waterfallChamber);
}
/*********************************SetGreatChasm()********************************
    Initializes the Great Chasm based on the player's inventory and whether
    the grappling hook has been thrown or not
********************************************************************************/
void SetGreatChasm(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm) {

    string description;

    if (hookedChasm) {
        description = "In the center of this room is a large CHASM splitting the room in two. You can't see the bottom. "
                    "You can see an exit to the EAST that you can now reach thanks to your grappling hook. The exit to the SOUTH "
                    "returns you to the entrance of the cavern.";
    }
    else {
        description = "In the center of this room is a large CHASM splitting the room in two. You can't see the bottom. "
                    "You can see an exit to the EAST, but you can't reach it without a way across the CHASM. The exit to the SOUTH "
                    "returns you to the entrance of the cavern.";
    }
    Room greatChasm("Great Chasm", description);
    if (!hookedChasm) {
        Object chasm("CHASM", "Try as you might to look deeper into the CHASM, you still can't see the bottom. Please don't jump in.", false);
        Object east("EAST", "You can see the eastern exit from here, but without a way across the CHASM there's no way in. There seems to be a "
                    "bit of noise coming from the exit and a vague scent of... enchiladas???", false);

        greatChasm.AddObject(chasm);
        greatChasm.AddObject(east);
    }
    else {
        Object chasm("CHASM", "temp", false);
        Exit east("EAST", "temp", "Casa Bonita");

        greatChasm.AddObject(chasm);
        greatChasm.AddExit(east);
    }

    Exit south("SOUTH", "The southern exit will return you to the entrance of the caverns.", "Entrance");

    greatChasm.AddExit(south);

    roomVector.push_back(greatChasm);
}
/*********************************SetRuinedPassage()*****************************
    Initializes the Ruined Passage based on the player's inventory and whether
    the grappling hook has been thrown
********************************************************************************/
void SetRuinedPassage(vector<Room>& roomVector, vector<Object> userInventory, bool hookedChasm) {

    Room ruinedPassage("Ruined Passage", "Much of this passageway has collapsed into heaps of rubble and stone. "
                       "It doesn't look like you can get through the COLLAPSED WALL blocking the east exit. The exit to "
                       "the WEST will return you to the entrance.");

    Object collapsedwall("COLLAPSED WALL", "The walls of the cave have completely collapsed together here. You can't get through. "
                  "However, you see a bit of ROPE wedged between a couple of stones here.", false);
    Object rope("ROPE", "Some sturdy looking rope. Probably would make a great lasso. Or grappling hook.", true);

    ruinedPassage.AddObject(collapsedwall);
    ruinedPassage.AddObject(rope);
    if (SearchInventory(userInventory, rope) || SearchInventory(userInventory, "GRAPPLING HOOK") || (hookedChasm == true)) {
        ruinedPassage.UpdateRoom(rope);
    }

    Exit west("WEST", "The western exit leads back to the entrance of the cavern.", "Entrance");

    ruinedPassage.AddExit(west);

    roomVector.push_back(ruinedPassage);

}

/********************************SetCasaBonita()*********************************
    Initializes Casa Bonita based on player's inventory and whether the
    flag has been raised
********************************************************************************/

void SetCasaBonita(vector<Room>& roomVector, vector<Object> userInventory, bool raisedFlag) {

    string description;

    if (raisedFlag && (!SearchInventory(userInventory, "ENCHILADA DINNER"))) {
        description = "The warm smell of Tex-Mex fills the air. Speakers, somewhere, are blasting mariachi music "
                    "and several diners are enjoying their meals. The host welcomes you and brings you to a table. On the table "
                    "is your ENCHILADA DINNER you had brought to you earlier. Exits are to the NORTH and WEST (returning you to the Chasm).";
    }
    else {
        description = "The warm smell of Tex-Mex fills the air. Speakers, somewhere, are blasting mariachi music "
                    "and several diners are enjoying their meals. The host welcomes you and brings you to a table. At the table "
                    "is a FLAG. Exits are to the NORTH and WEST (returning you to the Chasm).";
    }

    Room casaBonita("Casa Bonita", description);

    if (raisedFlag) {
        Object flag("FLAG", "The flag you raised to get a delicious Mexican platter. It's not useful anymore.", false);
        casaBonita.AddObject(flag);
    }
    else {
        Object flag("FLAG", "A flag attached to a wooden pole sits in the middle of the table. This certainly \"raises\" a few questions." , false);
        casaBonita.AddObject(flag);
    }

    Object enchiladaDinner("ENCHILADA DINNER", "A piping hot plate of enchiladas, rice, and beans. The heat coming off of the platter "
                           "is so intense, it could probably dry off something very wet. Try not to burn yourself.", true);


    //casaBonita.AddObject(flag);
    if (!(SearchInventory(userInventory, "ENCHILADA DINNER") || SearchInventory(userInventory, "DRY LOGS")) && raisedFlag) {
        casaBonita.AddObject(enchiladaDinner);
    }

    Exit west("WEST", "The western exit leads back to the great chasm.", "Great Chasm");
    Exit north("NORTH", "The northern exit is a door marked \"Pirate\". Or maybe it says \"Private\". You never learned how to read "
               "very well.", "Dead End");

    casaBonita.AddExit(west);
    casaBonita.AddExit(north);

    roomVector.push_back(casaBonita);
}

/********************************SetDeadEnd()************************************
    Initializes the dead end based the player's inventory and whether the
    wall has been blown up
********************************************************************************/
void SetDeadEnd(vector<Room>& roomVector, vector<Object> userInventory, bool blownWall) {

    string description;

    if (blownWall) {
        description = "Well this used to be a dead end, before you went and blew up the other wall. You still owe me money for repairs."
        "There are now exits to the NORTH and SOUTH. You monster.";
    }
    else {
        description = "You find yourself in a dead end. There is nothing this way but a totally not suspicious WALL. "
                 "Might as well head on back home. There's an exit to the SOUTH, and definitely not one to the NORTH.";
    }
    Room deadEnd("Dead End", description);



    Exit south("SOUTH", "The best exit in this room is the one to the south. Go ahead and go that way.", "Casa Bonita");
    if (blownWall) {
        Exit north("NORTH", "Well, there's an exit to the north now. Thanks to you. Go ahead and go, you've done enough damage.", "Dark Room");
        deadEnd.AddExit(north);
    }
    else {
        Object wall("WALL", "This wall isn't suspicious at all. There's no way that it is actually anything important. Definitely not "
                "the loose TILE in the middle.", false);
        Object tile("TILE", "The tile is a bit loose, and you notice a BUTTON behind it. Please don't try to use it. Please.", false);
        Object button("BUTTON", "A small, inconspicuous button. Seriously, don't use it. It's not for you.", false);

        deadEnd.AddObject(wall);
        deadEnd.AddObject(tile);
        deadEnd.AddObject(button);

        Object north("NORTH", "Why are you looking at the north? There's no exit here. Go back.", false);
        deadEnd.AddObject(north);
    }

    deadEnd.AddExit(south);

    roomVector.push_back(deadEnd);

}

/**********************************SetDarkRoom()*********************************
    Initializes the Dark Room based on the user's inventory
********************************************************************************/
void SetDarkRoom(vector<Room>& roomVector, vector<Object> userInventory) {

    string description;
    if (SearchInventory(userInventory, "fire")) {
        description = "The bright light from your fire fills the room, revealing that there is a second exit to the WEST in this room. "
                    "The room is otherwise completely empty. The exit to the SOUTH returns to the hallway (that you blew up, by the way).";
    }
    else {
        description = "This room is so dark, you can't see a thing. You don't dare to venture further in due to your fear "
                    "of the dark. The only thing to do is return to the SOUTH where you came from.";
    }

    Room darkRoom("Dark Room", description);


    Exit south("SOUTH", "The exit to the south leads back to the hallway (that you blew up, by the way).", "Dead End");

    darkRoom.AddExit(south);

    if (SearchInventory(userInventory, "fire")) {
        Exit west("WEST", "The exit to the west can now be seen due to the fire in your inventory. Who knows where it leads?", "Treasure Room");
        darkRoom.AddExit(west);
    }
    roomVector.push_back(darkRoom);
}

/*********************************SetTreasureRoom()******************************
                            Initializes the Treasure Room
********************************************************************************/
void SetTreasureRoom(vector<Room>& roomVector, vector<Object> userInventory) {

    Room treasureRoom("Treasure Room", "As you enter the treasure room, your eyes widen in disappointment due to the general lack of "
                      "treasure in the room. The blank, white room is empty aside from a single pedestal in the center, with a glass case "
                      "resting atop. You slowly walk your way over to the case... your gaze looks down onto your prize.... \"FREE DRINK WITH THE "
                      "PURCHASE OF ANY ENCHILADA DINNER AT CASA BONITA\" the coupon says. You can barely contain your excitement as you remove "
                      "the glass and reach out and grab the coupon to examine further, when you see it: \"EXPIRATION: Yesterday\". Maybe the "
                      "real treasure was the friends we made along the way.");



    roomVector.push_back(treasureRoom);

}
/*********************************SearchInventory********************************
    Searches the player's inventory for an Object and returns true if in
    the inventory, false if not.

    2 versions of this function: One receives the Object itself as an argument,
    and the other receives the object's name as a string
********************************************************************************/
bool SearchInventory(vector<Object> userInventory, Object target) {
    for (Object obj : userInventory) {
        if (obj == target)
            return true;
    }
    return false;
}

bool SearchInventory(vector<Object> userInventory, string target) {
    for (Object obj : userInventory) {
        if (StrToLower(obj.GetName()) == StrToLower(target))
            return true;
    }
    return false;
}
/**********************************PrintTitle()**********************************
            Prints the title screen of the game from a .txt file
********************************************************************************/
void PrintTitle()
{
    string   titleLine;
    ifstream ifs;
    ifs.open("title.txt");

    if (!ifs.is_open())
        cout << "TITLE SCREEN ERROR" << endl;
    else {
        while (!ifs.eof()) {
            getline(ifs, titleLine);
            cout << titleLine << endl << endl;
        }
        ifs.close();
    }

}

/*********************************FindRoom()********************************
    Searches room vector for a Room with a name matching the argument
    string
***************************************************************************/
Room FindRoom(string roomString, vector<Room>roomVector)
{
    for (Room room : roomVector){
        if (room.GetRoomName() == roomString) {
            return room;
        }
    }
    return roomVector.at(0);  //Defaults room number to starting room if unable to find room
}

/*********************************CreateItem()***********************************
    Receives a vector of strings as input, and initializes an Object instance
    with the first 2 strings of the vector.
    WARNING: This vector sent to this function must be validated to have a size
    of at least 2
********************************************************************************/
Object CreateItem(vector<string> inventoryStringVector) {
    Object object(inventoryStringVector.at(0), inventoryStringVector.at(1), true);

    return object;
}

/**********************************StrToLower()*********************************
        Returns an inputted string in all lowercase characters
*******************************************************************************/
string StrToLower(string inputStr) {
    string outputStr = inputStr;
    for(int i = 0; i < inputStr.length(); i++) {
        outputStr.at(i) = tolower(outputStr.at(i));
    }
    return outputStr;
}

/*********************************SplitString()*********************************
            Splits string into a vector by space characters
*******************************************************************************/
vector<string> SplitString(string inputStr) {
    vector<string> splitInput;

    string tempStr = "";

    for(int i = 0; i < inputStr.length(); i++) {
        if (inputStr.at(i) == ' ') {
            splitInput.push_back(tempStr);
            tempStr = "";
        }
        else {
            tempStr.push_back(tolower(inputStr.at(i)));
            if ( i == inputStr.length() - 1) {
                splitInput.push_back(tempStr);
                tempStr = "";
            }
        }
    }

    return splitInput;
}

